class GameObject {
    ID = 0;
    DisplayName = "GameObject";
    Description = "A game object.";
    OnRefresh() { };
    static Implementions = {};
};
module.exports = GameObject;